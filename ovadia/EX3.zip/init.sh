setenv LD_LIBRARY_PATH "/usr/local/lib/opencv-3.1.0/lib/"
